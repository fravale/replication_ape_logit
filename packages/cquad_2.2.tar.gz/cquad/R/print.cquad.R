print.cquad <-
function(x, ...){
	
# print output	
	cat("\nCall:\n")
    print(x$call)
    cat("\n")
    
}
